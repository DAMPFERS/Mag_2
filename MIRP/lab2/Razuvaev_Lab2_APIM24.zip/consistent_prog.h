#include <stdio.h>
#include <time.h>
#include <stdint.h>


uint32_t sumDigits(uint32_t n); //  вычисляет сумму цифр числа
int satisfies(uint32_t n, uint32_t *digitSum, int *exp);

char consistentMain();