#include "consistent_prog.h"

// Функция для вычисления суммы десятичных цифр числа
uint32_t sumDigits(uint32_t n) {
    uint32_t sum = 0;
    while (n > 0) {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}


// Функция проверяет, можно ли представить число n в виде (сумма цифр)^p, где p >= 2.
// Если да, возвращает 1 и записывает сумму цифр и степень в соответствующие переменные.
// Если нет – возвращает 0.
int satisfies(uint32_t n, uint32_t *digitSum, int *exp) {
    uint32_t s = sumDigits(n);
    // Если сумма цифр равна 0 или 1, то возведение в любую степень не даст n (исключаем)
    if (s <= 1)
        return 0;
    
    uint32_t power = s * s; // начинаем с p = 2
    int p = 2;
    // Пока значение степени не превысило n
    while (power <= n) {
        if (power == n) {
            *digitSum = s;
            *exp = p;
            return 1;
        }
        // Следующее возведение: умножаем текущий результат на s
        power *= s;
        p++;
    }
    return 0;
}


char consistentMain(){
    uint32_t N;
    printf("Enter a number N: ");
    scanf("%ld", &N);
    
    uint32_t candidate = N + 1; // начинаем поиск с N+1
    uint32_t s;
    int p;
    
    // Последовательный перебор кандидатов до нахождения нужного числа
    clock_t start = clock();
    while (1) {
        if (satisfies(candidate, &s, &p)) {
            clock_t end = clock();
            double time = (double)(end - start) / CLOCKS_PER_SEC;
            printf("Time:  %.6f seconds\n", time);
            printf("The number found: %ld = (%ld)^%d\n", candidate, s, p);
            break;
        }
        candidate++;
    }
    return 0;
}